# SWMD-0-MIN
id: 5877b8b2-3ee9-44e8-b58b-0bd19fd87ec4
title: Forecast Backstab

ENC enc_turn_1 turn=0..0
ORX opt_1_1/rxn_1_1_a -> enc_turn_2 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.4),P(power_england.pTrust[power_austria]),P(power_austria.pTrust[power_england]),P(power_england.pTrust[power_austria][power_france]))
ORX opt_1_1/rxn_1_1_b -> enc_turn_2 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.2),P(power_england.pThreat[power_austria]),P(power_austria.pThreat[power_england]),P(power_england.pThreat[power_austria][power_france]))
ORX opt_1_2/rxn_1_2_a -> enc_turn_2 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.4),P(power_england.pTrust[power_austria]),P(power_austria.pTrust[power_england]),P(power_england.pTrust[power_austria][power_france]))
ORX opt_1_2/rxn_1_2_b -> enc_turn_2 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.2),P(power_england.pThreat[power_austria]),P(power_austria.pThreat[power_england]),P(power_england.pThreat[power_austria][power_france]))
ORX opt_1_3/rxn_1_3_a -> enc_turn_2 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.4),P(power_england.pTrust[power_austria]),P(power_austria.pTrust[power_england]),P(power_england.pTrust[power_austria][power_france]))
ORX opt_1_3/rxn_1_3_b -> enc_turn_2 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.2),P(power_england.pThreat[power_austria]),P(power_austria.pThreat[power_england]),P(power_england.pThreat[power_austria][power_france]))

ENC enc_turn_2 turn=1..1
ORX opt_2_1/rxn_2_1_a -> enc_turn_3 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.4),P(power_england.pTrust[power_austria]),P(power_austria.pTrust[power_england]),P(power_england.pTrust[power_austria][power_france]))
ORX opt_2_1/rxn_2_1_b -> enc_turn_3 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.2),P(power_england.pThreat[power_austria]),P(power_austria.pThreat[power_england]),P(power_england.pThreat[power_austria][power_france]))
ORX opt_2_2/rxn_2_2_a -> enc_turn_3 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.4),P(power_england.pTrust[power_austria]),P(power_austria.pTrust[power_england]),P(power_england.pTrust[power_austria][power_france]))
ORX opt_2_2/rxn_2_2_b -> enc_turn_3 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.2),P(power_england.pThreat[power_austria]),P(power_austria.pThreat[power_england]),P(power_england.pThreat[power_austria][power_france]))
ORX opt_2_3/rxn_2_3_a -> enc_turn_3 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.4),P(power_england.pTrust[power_austria]),P(power_austria.pTrust[power_england]),P(power_england.pTrust[power_austria][power_france]))
ORX opt_2_3/rxn_2_3_b -> enc_turn_3 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.2),P(power_england.pThreat[power_austria]),P(power_austria.pThreat[power_england]),P(power_england.pThreat[power_austria][power_france]))

ENC enc_turn_3 turn=2..2
ORX opt_3_1/rxn_3_1_a -> enc_turn_4 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.4),P(power_england.pTrust[power_austria]),P(power_austria.pTrust[power_england]),P(power_england.pTrust[power_austria][power_france]))
ORX opt_3_1/rxn_3_1_b -> enc_turn_4 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.2),P(power_england.pThreat[power_austria]),P(power_austria.pThreat[power_england]),P(power_england.pThreat[power_austria][power_france]))
ORX opt_3_2/rxn_3_2_a -> enc_turn_4 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.6),P(power_england.pTrust[power_austria][power_france]))
ORX opt_3_2/rxn_3_2_b -> enc_turn_4 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.4),P(power_england.pTrust[power_austria][power_france]))
ORX opt_3_3/rxn_3_3_a -> enc_turn_4 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.6),P(power_england.pTrust[power_austria][power_france]))
ORX opt_3_3/rxn_3_3_b -> enc_turn_4 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.4),P(power_england.pTrust[power_austria][power_france]))

ENC enc_turn_4 turn=3..3
ORX opt_4_1/rxn_4_1_a -> enc_ending_1 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:SUB(P(power_england.Trust),P(power_england.Threat))
ORX opt_4_1/rxn_4_1_b -> enc_ending_1 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:SUB(P(power_england.Trust),P(power_england.Threat))
ORX opt_4_2/rxn_4_2_a -> enc_ending_1 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:SUB(P(power_england.Trust),P(power_england.Threat))
ORX opt_4_2/rxn_4_2_b -> enc_ending_1 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:SUB(P(power_england.Trust),P(power_england.Threat))
ORX opt_4_3/rxn_4_3_a -> enc_ending_1 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:SUB(P(power_england.Trust),P(power_england.Threat))
ORX opt_4_3/rxn_4_3_b -> enc_ending_1 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:SUB(P(power_england.Trust),P(power_england.Threat))

ENC enc_turn_5 turn=4..4
ORX opt_5_1/rxn_5_1_a -> enc_ending_1 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.4),P(power_england.pTrust[power_austria]),P(power_austria.pTrust[power_england]),P(power_england.pTrust[power_austria][power_france]))
ORX opt_5_1/rxn_5_1_b -> enc_ending_1 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.2),P(power_england.pThreat[power_austria]),P(power_austria.pThreat[power_england]),P(power_england.pThreat[power_austria][power_france]))
ORX opt_5_2/rxn_5_2_a -> enc_ending_1 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.6),P(power_england.pTrust[power_austria][power_france]))
ORX opt_5_2/rxn_5_2_b -> enc_ending_1 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.4),P(power_england.pTrust[power_austria][power_france]))
ORX opt_5_3/rxn_5_3_a -> enc_ending_1 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.6),P(power_england.pTrust[power_austria][power_france]))
ORX opt_5_3/rxn_5_3_b -> enc_ending_1 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.4),P(power_england.pTrust[power_austria][power_france]))

ENC enc_turn_6 turn=5..5
ORX opt_6_1/rxn_6_1_a -> enc_ending_2 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.4),P(power_england.pTrust[power_austria]),P(power_austria.pTrust[power_england]),P(power_england.pTrust[power_austria][power_france]))
ORX opt_6_1/rxn_6_1_b -> enc_ending_2 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.2),P(power_england.pThreat[power_austria]),P(power_austria.pThreat[power_england]),P(power_england.pThreat[power_austria][power_france]))
ORX opt_6_2/rxn_6_2_a -> enc_ending_2 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.6),P(power_england.pTrust[power_austria][power_france]))
ORX opt_6_2/rxn_6_2_b -> enc_ending_2 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.4),P(power_england.pTrust[power_austria][power_france]))
ORX opt_6_3/rxn_6_3_a -> enc_ending_2 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.6),P(power_england.pTrust[power_austria][power_france]))
ORX opt_6_3/rxn_6_3_b -> enc_ending_2 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.4),P(power_england.pTrust[power_austria][power_france]))

ENC enc_turn_7 turn=6..6
ORX opt_7_1/rxn_7_1_a -> enc_ending_3 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.4),P(power_england.pTrust[power_austria]),P(power_austria.pTrust[power_england]),P(power_england.pTrust[power_austria][power_france]))
ORX opt_7_1/rxn_7_1_b -> enc_ending_3 | O:Accept a forecast-backed alliance proposal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.2),P(power_england.pThreat[power_austria]),P(power_austria.pThreat[power_england]),P(power_england.pThreat[power_austria][power_france]))
ORX opt_7_2/rxn_7_2_a -> enc_ending_3 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.6),P(power_england.pTrust[power_austria][power_france]))
ORX opt_7_2/rxn_7_2_b -> enc_ending_3 | O:Accept a coordinated backstab plan. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.4),P(power_england.pTrust[power_austria][power_france]))
ORX opt_7_3/rxn_7_3_a -> enc_ending_3 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += -0.1; SET power_england.Trust += 0.2 | D:ADD(C(0.6),P(power_england.pTrust[power_austria][power_france]))
ORX opt_7_3/rxn_7_3_b -> enc_ending_3 | O:Defect from a coalition without direct betrayal. | E:SET power_england.Threat += 0.2; SET power_england.Trust += -0.15 | D:ADD(C(0.4),P(power_england.pTrust[power_austria][power_france]))

ENC enc_ending_1 turn=4..999

ENC enc_ending_2 turn=4..999

ENC enc_ending_3 turn=4..999
