﻿from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import torch

from runner.synthetic import ToyTRM, build_synthetic_tasks, run_episode, set_global_seed
from trm_trace.interventions import patch_state

from .common import write_json


def _parse_task_index(task_id: str) -> int:
    return int(task_id.split("_")[-1])


def _load_summary(path: Path) -> List[Dict[str, Any]]:
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def _make_patch_intervention(donor_trace: Dict[str, Any], t_patch: int):
    def intervention(t: int, state: torch.Tensor, aux: Dict[str, torch.Tensor]):
        if t != t_patch:
            return state, aux, {}
        trace_a = {"steps": [{"h": state.detach().cpu().numpy()}]}
        trace_b = {"steps": [{"h": donor_trace["steps"][t_patch]["h"]}]}
        patched_np, patch_log = patch_state(trace_a, trace_b, t=0)
        patched_state = torch.tensor(patched_np, dtype=state.dtype)
        return patched_state, aux, patch_log

    return intervention


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run state patching and estimate step causal contribution.")
    parser.add_argument("--summary-json", type=Path, required=True)
    parser.add_argument("--out-json", type=Path, default=Path("tools/bench/out/causality.json"))
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--steps", type=int, default=6)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    summary_rows = _load_summary(args.summary_json)
    set_global_seed(args.seed)
    model = ToyTRM()
    tasks = build_synthetic_tasks(num_tasks=len(summary_rows), seed=args.seed)

    by_task_id = {task["task_id"]: task for task in tasks}
    failures = [row for row in summary_rows if int(row["final_correct"]) == 0]
    corrects = [row for row in summary_rows if int(row["final_correct"]) == 1]

    if not failures or not corrects:
        payload = {
            "num_failures": len(failures),
            "num_correct": len(corrects),
            "step_causal_contribution": {},
            "rsi": 0.0,
            "note": "Need at least one failed and one correct trajectory to run patching.",
        }
        write_json(args.out_json, payload)
        print(f"Wrote causality analysis: {args.out_json}")
        return

    donor_id = corrects[0]["task_id"]
    donor_task = by_task_id[donor_id]
    donor_trace = run_episode(model=model, task=donor_task, steps=args.steps)

    flips_by_step = {t: 0 for t in range(args.steps)}
    delta_by_step = {t: [] for t in range(args.steps)}

    for fail_row in failures:
        task = by_task_id[fail_row["task_id"]]
        base = run_episode(model=model, task=task, steps=args.steps)
        base_correct = int(base["final_correct"])

        for t in range(args.steps):
            intervention = _make_patch_intervention(donor_trace=donor_trace, t_patch=t)
            patched = run_episode(model=model, task=task, steps=args.steps, intervention=intervention)
            patched_correct = int(patched["final_correct"])
            if base_correct == 0 and patched_correct == 1:
                flips_by_step[t] += 1

            patch_log = patched["steps"][t]["metrics"].get("intervention", {})
            if patch_log:
                delta_by_step[t].append(float(patch_log.get("delta_l2", 0.0)))

    num_failures = len(failures)
    step_contrib = {str(t): flips_by_step[t] / num_failures for t in range(args.steps)}
    mean_delta = np.mean([d for values in delta_by_step.values() for d in values]) if delta_by_step else 0.0
    mean_flip = np.mean(list(step_contrib.values())) if step_contrib else 0.0
    rsi = float(mean_flip / (mean_delta + 1e-6))

    payload = {
        "num_failures": num_failures,
        "num_correct": len(corrects),
        "donor_task_id": donor_id,
        "step_causal_contribution": step_contrib,
        "rsi": rsi,
    }
    write_json(args.out_json, payload)
    print(f"Wrote causality analysis: {args.out_json}")


if __name__ == "__main__":
    main()
