﻿import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import unittest

import numpy as np

from trm_trace.interventions import ablate_aux, add_direction, patch_state


class InterventionTests(unittest.TestCase):
    def test_patch_state_swaps_step(self):
        trace_a = {"steps": [{"h": np.array([0.0, 1.0], dtype=np.float32)}]}
        trace_b = {"steps": [{"h": np.array([3.0, 4.0], dtype=np.float32)}]}
        patched, log = patch_state(trace_a, trace_b, t=0)
        self.assertTrue(np.allclose(patched, np.array([3.0, 4.0], dtype=np.float32)))
        self.assertGreater(log["delta_l2"], 0.0)

    def test_add_direction(self):
        out, log = add_direction(np.array([1.0, 1.0]), np.array([0.5, -0.5]), alpha=2.0)
        self.assertTrue(np.allclose(out, np.array([2.0, 0.0])))
        self.assertGreater(log["delta_l2"], 0.0)

    def test_ablate_aux(self):
        aux = {"gate": np.array([1.0, 2.0]), "other": np.array([3.0])}
        out, log = ablate_aux(aux, keys=["gate"])
        self.assertTrue(np.allclose(out["gate"], np.zeros_like(aux["gate"])))
        self.assertEqual(log["count"], 1)


if __name__ == "__main__":
    unittest.main()
